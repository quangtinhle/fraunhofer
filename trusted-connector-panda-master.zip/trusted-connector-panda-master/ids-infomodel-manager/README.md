The _ids-infomodel-manager_ module contains the Information Model Manager, responsible for handling IDS information model. 
