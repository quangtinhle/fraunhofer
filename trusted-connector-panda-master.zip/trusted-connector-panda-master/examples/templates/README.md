This directory contains **gradle templates** for docker-compose YAML files, used to automate the creation of example ZIPs for the most recent docker tags.

The YAML files within the directories inside this directory should be kept in sync with their counterparts in examples root.

**Files inside this directory always overwrite equally named files from examples root during ZIP creation!**