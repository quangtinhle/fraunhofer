The _examples_ directory contains the examples described in https://industrial-data-space.github.io/trusted-connector-documentation/

For automated local creation of an example ZIP during build, pass the `-PexampleTag="x.x.x|develop|latest"` option to gradlew.