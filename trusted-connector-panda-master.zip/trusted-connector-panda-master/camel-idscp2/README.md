The _camel-idscp2_ module adds IDSCP2 support to the integrated Camel deployment. It creates a Camel Component to make IDSCP2 available for building Camel routes.
IDSCP2 itself and the application layer implementation are contained in modules _idscp2_ and _idscp2-app-layer_
