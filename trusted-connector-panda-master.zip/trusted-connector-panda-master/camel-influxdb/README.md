The _camel-influxdb_ module adds InfluxDB support to the integrated Camel deployment. It creates a Camel Component connect to an InfluxDB instance.
