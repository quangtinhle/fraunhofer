/*-
 * ========================LICENSE_START=================================
 * ids-ind2uce
 * %%
 * Copyright (C) 2017 - 2018 Fraunhofer AISEC
 * %%
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =========================LICENSE_END==================================
 */
/**
 *
 */

package de.fhg.iese.ids.ind2uce;

import com.google.gson.*;
import org.apache.camel.AsyncCallback;
import org.apache.camel.AsyncProcessor;
import org.apache.camel.CamelContext;
import org.apache.camel.Converter;
import org.apache.camel.Exchange;
import org.apache.camel.NamedNode;
import org.apache.camel.Processor;
import org.apache.camel.converter.stream.CachedOutputStream;
import org.apache.camel.util.ObjectHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import de.fhg.iese.ids.ind2uce.util.UcUtil;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;

/**
 * @author Robin Brandstaedter <Robin.Brandstaedter@iese.fraunhofer.de>
 */
public class Ind2uceProcessor implements AsyncProcessor {

	private  Gson gson = createGson();

  CamelContext context;

  NamedNode definition;

  Processor target;

  Processor nextTarget;
  

  private static final Logger LOGGER = LoggerFactory.getLogger(Ind2uceProcessor.class);

  public Ind2uceProcessor(CamelContext context, NamedNode definition, Processor target, Processor nextTarget) {
    this.setContext(context);
    this.setDefinition(definition);
    this.setNextTarget(nextTarget);
    this.setTarget(target);
	LOGGER.debug("MYDATA connected via Interceptor");
  }

	@Override
	public void process(Exchange exchange) throws Exception {
		LOGGER.info("NodeDefinition Id: " + definition.getId());
		if(definition.getId().startsWith("to")) {
			LOGGER.info("MYDATA Processor called with Exchange");
			this.enforce(exchange);
			this.target.process(exchange);
		}
	}

	@Override
	public boolean process(Exchange exchange, AsyncCallback asyncCallback){
		LOGGER.info("NodeDefinition Id: " + definition.getId());
  		if(definition.getId().startsWith("to")){
			LOGGER.info("MYDATA Processor called with Exchange and AsyncCallback" );
			this.enforce(exchange);
		}
		return this.forward(exchange, asyncCallback);
	}

	private void enforce(Exchange exchange) {
		String dataAsString = exchange.getIn().getBody(String.class);
		String messageAsString = exchange.getMessage().getBody(String.class);
		LOGGER.info("from: " + exchange.getFromEndpoint());
		LOGGER.info("target: " + target.toString());
//		LOGGER.info("target: " + nextTarget.toString());
//		LOGGER.info("NodeDefinition Id: " + definition.getId() + " DescrText: " + definition.getDescriptionText() + " Label: " + definition.getLabel() + " ShortName: " + definition.getShortName() + " Parent: " + definition.getParent());
		LOGGER.info("Message: " + messageAsString);
		LOGGER.info("Message Body: " + dataAsString);

		// TODO: get the ConnectionUuid, via Camel Exchange Object or via Usage Control
		// object (metadata and data)


		if(null != dataAsString){
			JsonElement transferedDataObject = getDataObject(dataAsString);


			if(null != transferedDataObject) {
				String targetArtifactId = "http://connector.sap.de/artifact/UUID-1234";
				IdsMsgTarget idsMsgTarget = new IdsMsgTarget();
				idsMsgTarget.setName("SAP Anwendung");
				idsMsgTarget.setAppUri(target.toString());


				if (null != transferedDataObject && !(CachedOutputStream.class.equals(transferedDataObject.getClass().getEnclosingClass()))) {
					LOGGER.info("Message Body In: " + transferedDataObject.toString());

					IdsUseObject idsUseObject = new IdsUseObject();
					idsUseObject.setTargetDataUri(targetArtifactId);
					idsUseObject.setMsgTarget(idsMsgTarget);
					idsUseObject.setDataObject(transferedDataObject);

					Object result = UcUtil.enforceUsageControl(idsUseObject);
					JsonElement jsonResult = new JsonObject();
					// LOGGER.info("Message Body Out: " + dataObject.toString());
					if (result instanceof LinkedTreeMap<?, ?>) {

						final LinkedTreeMap<?, ?> treeMap = (LinkedTreeMap<?, ?>) result;
						final JsonElement jsonElement = gson.toJsonTree(treeMap);
						jsonResult = jsonElement;
						LOGGER.info("MYDATA json result:" + jsonResult.toString() );
					}

					String transferDataAsString = gson.toJson(jsonResult);
					exchange.getIn().setBody(transferDataAsString, String.class);
					exchange.getMessage().setBody(transferDataAsString, String.class);
					LOGGER.info("Message After Body In: " + exchange.getIn().getBody(String.class));

				}
			}
		}

	}


  public void setContext(CamelContext context) {
    this.context = context;
  }

  public void setDefinition(NamedNode definition) {
    this.definition = definition;
  }

  public void setTarget(Processor target) {
    this.target = target;
  }

  public void setNextTarget(Processor nextTarget) {
    this.nextTarget = nextTarget;
  }

  private boolean forward(final Exchange exchange, final AsyncCallback asyncCallback) {
    try {
      if (this.target instanceof AsyncProcessor) {
        ((AsyncProcessor)this.target).process(exchange, asyncCallback);
        return true;
      } else {
        this.target.process(exchange);
        return false;
      }
    } catch (final Exception e) {
      LOGGER.error("Exception while forwarding the exchange [{}]", e);
      exchange.setException(e);
      return false;
    }
  }
  /**
   * Returns the converted value, or null if the value is null
   */
  @Converter
  public static Class<?> toClass(Object value, Exchange exchange) {
      if (value instanceof Class) {
          return (Class<?>) value;
      } else if (value instanceof String) {
          // prefer to use class resolver API
          if (exchange != null) {
              return exchange.getContext().getClassResolver().resolveClass((String) value);
          } else {
              return ObjectHelper.loadClass((String) value);
          }
      } else {
          return null;
      }
  }
  
	private JsonElement getDataObject(String s) {
		JsonElement returnObj = new JsonObject(

		);
		try {
			JsonElement jsonElement = gson.fromJson(s, JsonElement.class);
			if (null != jsonElement && !(jsonElement.isJsonArray() && jsonElement.getAsJsonArray().size() == 0)) {
				returnObj = jsonElement;
			}
		} catch (JsonSyntaxException jse) {
			LOGGER.error("JsonSyntaxException, while getting Json from String [{}]", jse);
		}
		return returnObj;
	}
	
	private Gson createGson() {

		Gson gson = new GsonBuilder().registerTypeAdapter(ZonedDateTime.class, new TypeAdapter<ZonedDateTime>() {
			@Override
			public void write(JsonWriter writer, ZonedDateTime zdt) throws IOException {
				writer.value(zdt.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
			}

			@Override
			public ZonedDateTime read(JsonReader in) throws IOException {
				return ZonedDateTime.parse(in.nextString(), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
			}
		}).enableComplexMapKeySerialization().create();
		
		return gson;
	}

	@Override
	public CompletableFuture<Exchange> processAsync(Exchange exchange) {
		return null;
	}
}
