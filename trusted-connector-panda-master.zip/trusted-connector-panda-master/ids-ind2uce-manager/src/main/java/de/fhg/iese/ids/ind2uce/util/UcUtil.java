package de.fhg.iese.ids.ind2uce.util;

import de.fhg.iese.ids.ind2uce.IdsUseObject;
import de.fhg.iese.ids.ind2uce.service.UcRestCallService;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class UcUtil {
	
	private static final String BASE_URL = "http://uc-app:9552";
	
	public static UcRestCallService ucRestCallService() {
		return new Retrofit.Builder().baseUrl(BASE_URL).addConverterFactory(GsonConverterFactory.create()).build().create(UcRestCallService.class);
	}
	
	public static Object enforceUsageControl(IdsUseObject idsUseObject) {
		Call<Object> callSync = ucRestCallService().enforceUsageControl(idsUseObject);
		try {
			Response<Object> response = callSync.execute();
			return response.body(); 
		}catch (Exception e) {
			return "";
		}
	}


}
