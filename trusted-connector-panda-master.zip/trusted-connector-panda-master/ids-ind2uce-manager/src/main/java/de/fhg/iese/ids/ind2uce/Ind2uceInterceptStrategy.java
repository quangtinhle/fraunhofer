package de.fhg.iese.ids.ind2uce;

import org.apache.camel.CamelContext;
import org.apache.camel.NamedNode;
import org.apache.camel.Processor;
import org.apache.camel.spi.InterceptStrategy;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Robin Brandstaedter <Robin.Brandstaedter@iese.fraunhofer.de>
 */
@Component(immediate = true, name = "mydata-camel-interceptor")
public class Ind2uceInterceptStrategy implements InterceptStrategy {
    @Override
    public Processor wrapProcessorInInterceptors(CamelContext context, NamedNode definition, Processor target,
                                                 Processor nextTarget) {
        return new Ind2uceProcessor(context, definition, target, nextTarget);
    }
}
