package de.fhg.iese.ids.ind2uce;

public class IdsMsgTarget {
	String name;
	String appUri;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAppUri() {
		return appUri;
	}
	public void setAppUri(String appUri) {
		this.appUri = appUri;
	}

}
