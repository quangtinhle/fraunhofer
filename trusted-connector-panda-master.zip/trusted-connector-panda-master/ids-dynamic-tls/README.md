The _ids-dynamic-tls_ module contains a custom SSLContextFactory for ACME integration. 
