The _idscp2_ implements the second version of the IDS Communication Protocol
