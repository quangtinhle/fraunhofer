The _ids-route-manager_ module contains the Route Manager, responsible for interfacing with Apache Camel. This Manage is able to deploy, start, stop and delete Camel routes.   
