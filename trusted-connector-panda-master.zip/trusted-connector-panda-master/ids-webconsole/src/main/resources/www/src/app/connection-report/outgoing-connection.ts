export class OutgoingConnection {
  public endpointIdentifier: string;
  public remoteAuthentication: string;
  public remoteIdentity: string;
  public attestationResult: string;
}
