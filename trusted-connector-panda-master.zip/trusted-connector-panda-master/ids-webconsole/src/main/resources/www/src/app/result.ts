import { Route } from './routes/route';

export class Result {
  public successful: boolean;
  public message: string;
}
