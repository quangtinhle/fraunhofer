export interface Policy {
  policy_name: string;
  policy_description: string;
}
