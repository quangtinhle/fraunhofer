export interface TermsOfService {
    tos: string;
    isUri: boolean;
    error: null | string;
}
