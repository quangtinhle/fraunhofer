export class Cml {
  // tslint:disable-next-line:variable-name
  public cml_version: string;
}
