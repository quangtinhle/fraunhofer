import { CounterExample } from './counter-example';

export class ValidationInfo {
    public valid = true;
    public counterExamples?: CounterExample[];
}
