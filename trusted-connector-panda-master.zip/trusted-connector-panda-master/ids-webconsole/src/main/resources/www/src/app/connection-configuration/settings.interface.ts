export interface Settings {
  securityProfile: string;
}
