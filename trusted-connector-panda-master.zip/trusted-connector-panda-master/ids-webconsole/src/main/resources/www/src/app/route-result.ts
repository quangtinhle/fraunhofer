import { Route } from './routes/route';
import { Result } from './result';

export class RouteResult extends Result {
  public route?: Route;
}
