export class CounterExample {
    public explanation?: string;
    public steps?: string[];
}
