The _ids-comm_ module wraps the IDSCP, providing secure communication and remote attestation between Connector instances.
