package routing;

public interface RoutingService {

    String getRegistryEndpoint();
    String getRepositoryEndpoint();
}
